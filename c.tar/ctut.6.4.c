/* SCOPE */
/* */
/***************************************************************/
#include <stdio.h>
void main ()
{
	int my_var = 3;
	{
		int my_var = 5;
		printf ("my_var=%d\n", my_var);
	}
	printf ("my_var=%d\n", my_var);

}
