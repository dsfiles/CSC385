#include <stdio.h>
void main() 
{
	int* p; // p is a pointer to an integer
	printf("value of p is %p\n",p);
	printf("value in p is %d\n", *p);
	int i; // i is an integer
	p = &i; // Set p to point to i

	printf("value of p is %p\n",p);
        printf("value in p is %d\n", *p);
	
	*p = 13; // Change what p points to -- in this case i -- to 13
        printf("value of p is %p\n",p);
        printf("value in p is %d\n", *p);        

	// At this point i isa 13. So is *p. In fact *p
}
