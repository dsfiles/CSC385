#include <stdio.h>
#include <unistd.h>
int main()
{
	printf("before first fork\n");
	fork();
	printf("between 1st and 2nd fork\n");
	fork();
	printf("between 2nd and 3rd fork\n");
	fork();
	printf("after 3rd fork\n");

}
